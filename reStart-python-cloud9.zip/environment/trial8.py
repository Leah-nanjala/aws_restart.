print("Welcome to Guess the Number!")
print("The rules are simple. I will think of a number, and you will try to guess it.")